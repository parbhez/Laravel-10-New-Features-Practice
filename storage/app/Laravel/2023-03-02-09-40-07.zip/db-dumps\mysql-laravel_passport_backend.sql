
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,'VpBRR6vunx-1','MHQ2neTjfTqdHR1AT9mh6HemmnFLAlRNBSOSmMl0933CMaOeHmTOiTG0NB0XZTqvC99vzYhyQfjrTuUufEnXRytpJpDFsw1Mkq7ytest-1',NULL,NULL),(2,'0TDkrWZXxB-2','iuUIZYlYlmu4edHpKpbmLmmr4gxhmvZRqOa1XvtUfarIUAZUlGVZBzZS1eh0fFFkZVZeALpk5GWwK5Ap1sUZtKTU99043p2p9QNutest-2',NULL,NULL),(3,'naXP7bj6cM-3','GHtmcmiL52zgfg5vbxzKiufDZ4B6GEMC2NpMHPaa47XfNBnQjCiUEctGS1KMcbGOwTsS0ORzINZr7q1HoyZfzjqahNYdqN5l1Jt0test-3',NULL,NULL),(4,'Ky9xnrTXUl-4','rutQ5NKWpWTRwvbVxvZsYiS2aKli3GEjAHl08HnzLyfKEIvim86LgK3ZabwgJZhl7PI3jQl0Gux6OatQj9T2tjn8yuIbSMRPXejntest-4',NULL,NULL),(5,'4Y1vbVy2rz-5','dWAmdulmENREGfaOo9J4iskTkVTaiufDvD9rhcGchNQfYx5fv9sohtezvku3WEaoPounl3RbYJSVyWcvPywJMinOfxhe66TcFU8Xtest-5',NULL,NULL),(6,'TCzYn6oYAA-6','ikzkJ0HBwLdraxAe5iKSvvpWxfszbx1cWMDlbBxZNWzbkfEhfC5YoAlQ1f9YVgqTqtgrccYLQZGQNUTXcdbXgNf7AKQvTOke0H6Rtest-6',NULL,NULL),(7,'pULITJSz4b-7','kNlo0P5EjNZVx9pBtBKwlCjQqCUs2ne7uMQSYULUXERvTgDyzcXcoZyfKnc665pi5cCp7jMf30uLkZS0S1Vf3Tunje1MFyE8jEs8test-7',NULL,NULL),(8,'F5gLwxAW2Q-8','IvGSn6inDCCmwlBCmI1nv5wBruCeXLRk82wYVMY1ZqTc2sHuKpVEm26o6HTOrbBqYBumasYsGK6XnRcqiZAZmsrOyn6HPys1sRRstest-8',NULL,NULL),(9,'d0gPD4lXaQ-9','fnZ9dtqpPBLt1v32fxEmu5q4kY7bmQAs7pxRVEA0PueEbOhBqCLffFv4GSpDsXMC2IZivjzI5yzuopDASWM5p3AGthg7gURCQZ54test-9',NULL,NULL),(10,'wTOhQxzg4I-10','BrOwdH8wL2lgXDNzk5U5GefzII2IM9C7ZTlmzg9I9UsH1veRTCnDQUnDAQvsO2ghico3raBqEUGKUsgzL1658jpvdA7o5lh1m46Ttest-10',NULL,NULL),(11,'5cPD6A4YUk-11','s8MZJ8gq3NgKB9xsdTH5LxnmdIuYk5JizPe2bLMHnRpS6AsdzGriuHsg7M9SBlJrHtr4HY7DC9tDuTvKXXjmBLQKlzCGHOY0fXKUtest-11',NULL,NULL),(12,'dSwxgwEP6a-12','XK4mwKArn7EQje5dBZHEzRuQ0q80KQYcevwzop6TjoKbT3JwaNZuqgDZL7E9i4KbASDWhvQM0hnP6rGk1EsZTtwWVF58iojvn2Iptest-12',NULL,NULL),(13,'zmdALE8sSh-13','LD3n6D1W02aETs9k5BHYvisr2EtyweQrWP13eVRR7bTwnQf4KOv3VHzp1jgmmvHwSVACp8gj841Dw2TfmYZsjuxpFvahwvxYAKbZtest-13',NULL,NULL),(14,'Pp1Rjc7zV1-14','JbX0Ok7jZ6ZwQwHFYvjPxZ3MGK7frnudY680tydDKj6cQi4npKf7w4zGr6q34v4Pxe4tikAkPn885Rly6UMg4fOXVMsulEPEBNW8test-14',NULL,NULL),(15,'zNOwFoISu2-15','Bz4Ah3bLJxBviz4ZT1Dd64TzPIPokjpeAJ74FjeOAa28ByzgdZ3bGjvXTtSgAjf6tgQuFjxEDi8vDOA8JYQJQeJLdc0Ue22l54RVtest-15',NULL,NULL),(16,'TzHEseNHBH-16','iNSNxFlmLUUwxvM4QydZDSQfR273h6vsKpBsqCC970vl5yQhmZBCh27vpnVzBn8335UP9L9Of6d3XhIBZKxeiFmBwfarXx6H25drtest-16',NULL,NULL),(17,'777fUL8fWa-17','yHjOsAm62EWw92ddPGI1ahoNW8TzQMOrai2jJs1DHdwz65je9IFfn2ezEzo0NnXyZRGD1kc9Y5U43p7wXMTnG0gXiIsYID1d5PNstest-17',NULL,NULL),(18,'Ic2s1rxN2z-18','ivM4RYCwasOqeV3H2SUsqJbjxoqUJz6nVq9Fy4gp4h7oum9R6Lp7tbiItTI0SZKZnrFhd3F5PKj5YxSWNTDlErQuCH7ld7mW9bFJtest-18',NULL,NULL),(19,'L19jfnabdU-19','BwWCUWpqzmsHoU9PFIxTkWdqxJa3F7wDmESQTKYCoTYZahTvAVaMcrI3Ql1FxMrMvqtshXKIBJonzwKdglHiOVHBPjkImY3pnJOstest-19',NULL,NULL),(20,'sMM3qandS6-20','LC6qgqpc6Ka0DdcWTi7py5rykRT74085W7RPEs5TVgkCZRlqSyvYlLfsZSNjX3xlQiAfdVtseLq64A9XJ8IBV4KxCH4xSJVZRrxBtest-20',NULL,NULL);
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2016_06_01_000001_create_oauth_auth_codes_table',1),(4,'2016_06_01_000002_create_oauth_access_tokens_table',1),(5,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(6,'2016_06_01_000004_create_oauth_clients_table',1),(7,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(8,'2019_08_19_000000_create_failed_jobs_table',1),(9,'2019_12_14_000001_create_personal_access_tokens_table',1),(10,'2023_02_27_073136_create_admins_table',1),(11,'2023_02_27_133941_create_blogs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('240191fc6532d65881abe28cda4b6f0e2a354d0936cfbb465a5007e1f7487172c192b166bac7bbcc',1,1,'accessToken','[]',1,'2023-02-28 08:01:32','2023-02-28 08:02:39','2024-02-28 14:01:32'),('2659e62dd6ccf2a018615a88dd2b0af800fc717a45c12871907c6358235d80381ed13b99da0f1015',1,1,'accessToken','[]',1,'2023-02-28 07:00:35','2023-02-28 07:01:04','2024-02-28 13:00:35'),('2d082952ec48d6775349fc93b3b93c862c1d9bc168d9ea52e98a5021ea94560a1334ded35eecdc76',1,1,'accessToken','[]',1,'2023-03-01 00:33:50','2023-03-01 01:02:08','2024-03-01 06:33:50'),('3bf931925b40f64d560043c6821c38ed61cf09a9369aa1ca0586a77c7d2699c6a65cfbc30574c884',1,1,'accessToken','[]',1,'2023-02-28 07:36:17','2023-02-28 07:38:00','2024-02-28 13:36:17'),('3fade85509eab16b6c8907d11770fd34ae2f6c7fdda31edae2964c9da1145c58487c9d0c42f14390',1,1,'accessToken','[]',1,'2023-02-28 07:21:42','2023-02-28 07:23:32','2024-02-28 13:21:42'),('5b2a42cb9a9acab7c1fd87bfd54725b77087eab02c85517ae700018f8aa0aae75bfc6a5a69656c17',1,1,'accessToken','[]',1,'2023-02-28 08:15:29','2023-02-28 08:15:36','2024-02-28 14:15:29'),('6e8a5724ab05d821c3ceae8f858e0bbd865a8ad9dbc972b485f2182350e8e4ceae64ceb3073ef307',1,1,'accessToken','[]',1,'2023-02-28 07:50:07','2023-02-28 07:57:13','2024-02-28 13:50:07'),('6f3370325b82a63a9c74ec43bf637ae6152aa042ebed8653a34ec02002e1d1bc828e6dd908bffb0c',1,1,'accessToken','[]',0,'2023-03-01 01:21:20','2023-03-01 01:21:20','2024-03-01 07:21:20'),('76a3efdc07a1e219a2aee8ee53466b05c8bf3ca01d58e20e3d2ef6ffb9826c0f44119f9db8d99cde',1,1,'accessToken','[]',0,'2023-03-01 01:03:02','2023-03-01 01:03:02','2024-03-01 07:03:02'),('81695145c4e01ee7e7afb004edf6ffad97672d2a88ff058e2116c347e03b72bbdaae8a0816d8f7b6',1,1,'accessToken','[]',1,'2023-03-01 00:30:40','2023-03-01 00:31:52','2024-03-01 06:30:40'),('a28f0c9824f7996cefae622670276924cbfcdf121c66e41113428d4f8b1cea490694be5983bd3176',1,1,'accessToken','[]',0,'2023-02-28 23:51:25','2023-02-28 23:51:25','2024-03-01 05:51:25'),('c2a9188ba511a660b76b84b7b9efbb9a6354e7e34df7f44b47f4c29a8e577997d687dad0ca5ee5e2',1,1,'accessToken','[]',1,'2023-03-01 00:33:35','2023-03-01 00:33:44','2024-03-01 06:33:35'),('c67dec58a979d65547e97069c86883cf82eaa2c8c97b75ef8edea018d65a2b9e51bc89a42f4749f0',1,1,'accessToken','[]',1,'2023-02-28 06:29:58','2023-02-28 06:30:44','2024-02-28 12:29:58'),('c689a8a2235d24e4b11a4c758b2714ef382960e121296a2a6f3b34446d9044986b36c17c7e2af2d0',1,1,'accessToken','[]',1,'2023-03-01 00:27:26','2023-03-01 00:30:00','2024-03-01 06:27:26'),('cae1461f2dce095e9c2ffff945471003c52cf43b8d5f6d690a8966967af4904e563fc7de316e5c30',1,1,'accessToken','[]',1,'2023-02-28 07:02:37','2023-02-28 07:02:50','2024-02-28 13:02:37'),('cd1b864301b5faf23326a5603eaa79efe6ccd0faa1beded861c195073b5c9b256183e4b4cb2558d1',1,1,'accessToken','[]',1,'2023-02-28 07:57:19','2023-02-28 08:01:24','2024-02-28 13:57:19'),('ce9e76ac9d274a5e758c99c904df7a59d9fc2bc651b842ff870f7c5472790c75d52c8cced0f5883b',1,1,'accessToken','[]',1,'2023-02-28 06:59:29','2023-02-28 06:59:39','2024-02-28 12:59:29'),('d6cb6521b87b881ead8ef563c75ff11c925b9923f8076b5c247f694400e92d0b1888f4149cfe2485',1,1,'accessToken','[]',1,'2023-02-28 07:01:47','2023-02-28 07:01:53','2024-02-28 13:01:47'),('e645d42165df278d14e38f9eadf6b7c48b538e5d5ef5cc8d3f95880bc6832a3e3336def3495082cf',1,1,'accessToken','[]',1,'2023-03-01 01:02:12','2023-03-01 01:19:30','2024-03-01 07:02:12'),('e7e3bea36495819f4a2f533c6c1a97573e42dd0c7ba44284180bb973f718ce2f8d834f8c49509498',1,1,'accessToken','[]',1,'2023-03-01 00:53:16','2023-03-01 00:54:21','2024-03-01 06:53:16'),('ec1816edfc3fda13c76f201306417f59a5fc314ff1e65fed21e3cd9a27d55bded2026f592fb07d97',1,1,'accessToken','[]',1,'2023-02-28 06:58:26','2023-02-28 06:58:38','2024-02-28 12:58:26');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'Laravel Personal Access Client','lbinAMRThruWA06nBwXOn0EbRukDEheVVMJngdoI',NULL,'http://localhost',1,0,0,'2023-02-28 06:29:22','2023-02-28 06:29:22'),(2,NULL,'Laravel Password Grant Client','fbPbHXUczg12LlPdMWelJdd7ZShgSejX2B9YKugO','users','http://localhost',0,1,0,'2023-02-28 06:29:22','2023-02-28 06:29:22');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2023-02-28 06:29:22','2023-02-28 06:29:22');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@gmail.com',NULL,'$2y$10$q.rsg3DlXWshBg/qvpF0lehjwrO76GWsn5OwG0XC0TxiWnnj.FSSO',NULL,'2023-02-28 06:29:08','2023-02-28 06:29:08'),(2,'Masud','masud@gmail.com',NULL,'$2y$10$PnsmcYbTAP/BnmwjsSxNv.o2oWcpnDQs47KrqlJUkZtz0Th1g1WlO',NULL,'2023-02-28 07:44:23','2023-02-28 07:44:23'),(3,'Masud','masud@mail.com',NULL,'$2y$10$Rcr/ZG/cNiB3MLkBU1jOS.8L80N7UmINcwYEKwwlitKovAKF3hPJO',NULL,NULL,NULL),(5,'Masud','masud1@mail.com',NULL,'$2y$10$I/f5Q5.KVAJy687dklsY0eJseLwLzc3mXLA.55W4GsM7XyotyfmCu',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

